# iOS 26.2 measurements

All six flows passed on Xcode 26.2 / iOS 26.2 with stock Maestro 2.11.0.
The numbered folders preserve every sample in order. Native and CLI logs use UTC.

Recalculate a sample from its raw logs:

```sh
awk -f measure.awk 1-static/maestro.log 1-static/native.log
```

The interval begins at the unique CLI Swipe RUNNING line and ends at native POST /swipeV2 receipt. The counter includes only hierarchy and screen-static requests before that receipt and reports the source line numbers. It does not measure first touch or completed query CPU time.

The runner load was high, especially at startup; treat times as this run’s observations. File environment.txt records the toolchain and image. Workflow reproduce.yml ran commit 592a4103a182c988c0cab6e60880d045eef954ed, with static/moving, moving/static, static/moving pair order.

post-settle-summary.json gives the separate interval from the second CLI `Waiting for animation to end` line to `Swipe … COMPLETED`, including both line numbers. It can include command-completion work after settling returns. These values use the same raw CLI logs; they are not gesture duration.
