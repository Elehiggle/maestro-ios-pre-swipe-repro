# Usage: awk -f ci/measure.awk sample/maestro.log sample/native.log
# Both inputs must use UTC, with exactly one swipe and no midnight crossing.
function seconds(value, parts) {
    split(value, parts, ":")
    return parts[1] * 3600 + parts[2] * 60 + parts[3]
}
FNR == NR {
    if (/CliConsoleListener.onCommandStart: Swipe .* RUNNING$/) {
        starts++
        start = seconds($1)
        start_text = $1
        start_line = FNR
    }
    next
}
/^[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] / {
    if (date_seen != "" && $1 != date_seen) crossed_midnight = 1
    date_seen = $1
    time = seconds($2)
    if (/request: POST \/swipeV2$/) {
        swipes++
        if (swipes == 1) {
            dispatch = time
            dispatch_text = $2
            dispatch_line = FNR
        }
    }
    if (time >= start && swipes == 0) {
        if (/request: POST \/viewHierarchy$/) hierarchies++
        if (/request: GET \/isScreenStatic$/) static_checks++
    }
}
END {
    if (starts != 1 || swipes != 1 || crossed_midnight || dispatch < start) {
        printf "No measurement: CLI swipe starts=%d native swipe receipts=%d midnight=%d; inspect raw logs and clocks.\n", starts, swipes, crossed_midnight > "/dev/stderr"
        exit 1
    }
    print "cli_start_utc\tcli_line\tnative_receipt_utc\tnative_line\tpre_dispatch_seconds\thierarchy_requests\tscreen_static_requests"
    printf "%s\t%d\t%s\t%d\t%.3f\t%d\t%d\n", start_text, start_line, dispatch_text, dispatch_line, dispatch - start, hierarchies, static_checks
}
